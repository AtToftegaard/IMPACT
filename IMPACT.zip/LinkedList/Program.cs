﻿using LinkedList;

var linkedList = new CustomLinkedList<string>();

linkedList.Add("string1");
linkedList.Add("string2");
linkedList.Add("string3");

Console.WriteLine(linkedList);
